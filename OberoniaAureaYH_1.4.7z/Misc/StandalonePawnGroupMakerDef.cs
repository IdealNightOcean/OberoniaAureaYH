﻿using RimWorld;
using System.Collections.Generic;
using Verse;

namespace OberoniaAurea;

public class StandalonePawnGroupMakerDef : Def
{
    public List<PawnGroupMaker> pawnGroupMakers;
}